package solitaire;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Automated JUnit 5 tests for the Sprint 2 game logic.
 * The tests avoid Swing so they can check the rules quickly and consistently.
 */
class PegSolitaireGameTest {

    @Test
    void englishBoardStartsWithEmptyCenter() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);

        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(3, 3));
        assertEquals(BoardType.ENGLISH, game.getBoardType());
    }

    @Test
    void hexagonBoardStartsWithEmptyCenter() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.HEXAGON);

        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(3, 3));
        assertEquals(BoardType.HEXAGON, game.getBoardType());
    }

    @Test
    void diamondBoardStartsWithEmptyCenter() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.DIAMOND);

        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(3, 3));
        assertEquals(BoardType.DIAMOND, game.getBoardType());
    }

    @Test
    void newGameUsesChosenSizeAndType() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);

        game.startNewGame(9, BoardType.DIAMOND);

        assertEquals(9, game.getSize());
        assertEquals(BoardType.DIAMOND, game.getBoardType());
        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(4, 4));
    }

    @Test
    void startingAnotherGameResetsTheBoard() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);
        assertTrue(game.makeMove(1, 3, 3, 3));
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(3, 3));

        game.startNewGame(7, BoardType.ENGLISH);

        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(3, 3));
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(1, 3));
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(2, 3));
    }

    @Test
    void orthogonalJumpIsRecognizedAsValid() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);

        assertTrue(game.isValidMove(1, 3, 3, 3));
    }

    @Test
    void diagonalJumpIsRecognizedAsValid() {
        // Size 9 gives the Diamond board enough room for a diagonal jump into the center.
        PegSolitaireGame game = new PegSolitaireGame(9, BoardType.DIAMOND);

        assertTrue(game.isValidMove(2, 2, 4, 4));
    }

    @Test
    void validMoveMovesPegAndRemovesJumpedPeg() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);

        assertTrue(game.makeMove(1, 3, 3, 3));

        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(1, 3));
        assertEquals(PegSolitaireGame.CellState.EMPTY, game.getCell(2, 3));
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(3, 3));
    }

    @Test
    void invalidMoveIsRejectedAndBoardDoesNotChange() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);
        int pegsBefore = game.countPegs();

        // Destination (2,3) already contains a peg, so this move is invalid.
        assertFalse(game.makeMove(0, 3, 2, 3));

        assertEquals(pegsBefore, game.countPegs());
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(0, 3));
        assertEquals(PegSolitaireGame.CellState.PEG, game.getCell(2, 3));
    }

    @Test
    void newGameIsNotImmediatelyOver() {
        PegSolitaireGame game = new PegSolitaireGame(7, BoardType.ENGLISH);

        assertFalse(game.isGameOver());
        assertTrue(game.hasValidMoves());
    }

    @Test
    void ratingsMatchTheProjectSpecification() {
        assertEquals("Outstanding", PegSolitaireGame.ratingForPegCount(1));
        assertEquals("Very Good", PegSolitaireGame.ratingForPegCount(2));
        assertEquals("Good", PegSolitaireGame.ratingForPegCount(3));
        assertEquals("Average", PegSolitaireGame.ratingForPegCount(4));
        assertEquals("Average", PegSolitaireGame.ratingForPegCount(10));
    }
}
