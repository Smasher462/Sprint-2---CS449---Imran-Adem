
package solitaire;

import javax.swing.*;
import java.awt.*;

/**
 * Swing user interface for Sprint 2.
 *
 * This class displays the game and receives player input.
 * All game rules are handled separately by PegSolitaireGame.
 */
public class SolitaireGUI extends JFrame {

    private final JSpinner sizeSpinner =
            new JSpinner(new SpinnerNumberModel(7, 5, 15, 2));

    private final JRadioButton englishButton =
            new JRadioButton("English", true);

    private final JRadioButton hexagonButton =
            new JRadioButton("Hexagon");

    private final JRadioButton diamondButton =
            new JRadioButton("Diamond");

    private final JPanel boardPanel = new JPanel();

    private final JLabel statusLabel = new JLabel(
            "Select settings and press New Game.",
            SwingConstants.CENTER
    );

    private int selectedSize = 7;
    private BoardType selectedType = BoardType.ENGLISH;

    private PegSolitaireGame game =
            new PegSolitaireGame(selectedSize, selectedType);

    // Stores the first selected peg.
    // -1 means no peg is selected.
    private int selectedRow = -1;
    private int selectedCol = -1;

    public SolitaireGUI() {
        super("Peg Solitaire - Sprint 2");
        configureWindow();
        createControls();
        refreshBoard();
    }

    // Set up the main window.
    private void configureWindow() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        setMinimumSize(new Dimension(650, 650));
    }

    // Create the board size, board type, and New Game controls.
    private void createControls() {
        JPanel topPanel = new JPanel(new FlowLayout());

        topPanel.add(new JLabel("Board size:"));
        topPanel.add(sizeSpinner);

        // Only allow supported odd board sizes.
        JSpinner.DefaultEditor sizeEditor =
                (JSpinner.DefaultEditor) sizeSpinner.getEditor();

        sizeEditor.getTextField().setEditable(false);

        // Only one board type can be selected.
        ButtonGroup boardTypeGroup = new ButtonGroup();

        boardTypeGroup.add(englishButton);
        boardTypeGroup.add(hexagonButton);
        boardTypeGroup.add(diamondButton);

        topPanel.add(new JLabel("Board type:"));
        topPanel.add(englishButton);
        topPanel.add(hexagonButton);
        topPanel.add(diamondButton);

        JButton newGameButton = new JButton("New Game");
        topPanel.add(newGameButton);

        // Remember selected board size.
        sizeSpinner.addChangeListener(
                event -> updateSelectedSize()
        );

        // Remember selected board type.
        englishButton.addActionListener(
                event -> updateSelectedType(BoardType.ENGLISH)
        );

        hexagonButton.addActionListener(
                event -> updateSelectedType(BoardType.HEXAGON)
        );

        diamondButton.addActionListener(
                event -> updateSelectedType(BoardType.DIAMOND)
        );

        // Start a new game when the button is clicked.
        newGameButton.addActionListener(
                event -> startNewGameFromControls()
        );

        add(topPanel, BorderLayout.NORTH);
        add(boardPanel, BorderLayout.CENTER);
        add(statusLabel, BorderLayout.SOUTH);
    }

    // Store the selected board size.
    private void updateSelectedSize() {
        selectedSize = (Integer) sizeSpinner.getValue();
    }

    // Store the selected board type.
    private void updateSelectedType(BoardType type) {
        selectedType = type;
    }

    // Create a new board using the selected settings.
    private void startNewGameFromControls() {
        game.startNewGame(selectedSize, selectedType);

        clearSelection();

        statusLabel.setText(
                "New " + selectedType + " game started. Pegs: "
                        + game.countPegs()
        );

        refreshBoard();
    }

    /**
     * Display the current board.
     */
    private void refreshBoard() {
        int size = game.getSize();

        boardPanel.removeAll();

        if (game.getBoardType() == BoardType.HEXAGON) {

            // Center the entire hexagon inside the window.
            boardPanel.setLayout(new GridBagLayout());

            JPanel hexagonRows =
                    new JPanel(new GridLayout(size, 1));

            for (int row = 0; row < size; row++) {

                // Center each row of the hexagon.
                JPanel centeredRow = new JPanel(
                        new FlowLayout(FlowLayout.CENTER, 0, 0)
                );

                for (int col = 0; col < size; col++) {

                    if (game.getCell(row, col)
                            != PegSolitaireGame.CellState.INVALID) {

                        JButton cellButton =
                                createCellButton(row, col);

                        cellButton.setPreferredSize(
                                new Dimension(44, 44)
                        );

                        centeredRow.add(cellButton);
                    }
                }

                hexagonRows.add(centeredRow);
            }

            boardPanel.add(hexagonRows);

        } else {

            // Original layout for English and Diamond.
            boardPanel.setLayout(
                    new GridLayout(size, size, 2, 2)
            );

            for (int row = 0; row < size; row++) {
                for (int col = 0; col < size; col++) {

                    if (game.getCell(row, col)
                            == PegSolitaireGame.CellState.INVALID) {

                        boardPanel.add(new JLabel());

                    } else {

                        boardPanel.add(
                                createCellButton(row, col)
                        );
                    }
                }
            }
        }

        // Update the GUI after changing the board.
        boardPanel.revalidate();
        boardPanel.repaint();

        pack();
        setLocationRelativeTo(null);
    }

    // Create a clickable button for each valid board hole.
    private JButton createCellButton(int row, int col) {

        boolean occupied =
                game.getCell(row, col)
                        == PegSolitaireGame.CellState.PEG;

        JButton cellButton =
                new JButton(occupied ? "●" : "");

        cellButton.setFocusPainted(false);

        cellButton.setToolTipText(
                "Row " + row + ", Column " + col
        );

        cellButton.addActionListener(
                event -> handleCellClick(row, col)
        );

        return cellButton;
    }

    /**
     * Handle a player's move using two clicks.
     *
     * First click: select a peg.
     * Second click: select its destination.
     */
    private void handleCellClick(int row, int col) {

        // Do not allow moves after the game ends.
        if (game.isGameOver()) {
            statusLabel.setText(
                    "Game over. Rating: " + game.getRating()
            );
            return;
        }

        // First click must select an occupied hole.
        if (selectedRow == -1) {

            if (game.getCell(row, col)
                    == PegSolitaireGame.CellState.PEG) {

                selectedRow = row;
                selectedCol = col;

                statusLabel.setText(
                        "Peg selected. Choose an empty destination."
                );

            } else {

                statusLabel.setText("Select a peg first.");
            }

            return;
        }

        // Clicking the same peg cancels the selection.
        if (selectedRow == row && selectedCol == col) {

            clearSelection();

            statusLabel.setText("Selection cleared.");
            return;
        }

        // Ask the game logic whether the move is valid.
        boolean moved = game.makeMove(
                selectedRow, selectedCol, row, col
        );

        clearSelection();

        // Reject invalid moves without changing the board.
        if (!moved) {

            statusLabel.setText(
                    "Invalid move. The board was not changed."
            );

            return;
        }

        // Display the updated board after a successful move.
        refreshBoard();

        // Check whether the game has finished.
        if (game.isGameOver()) {

            statusLabel.setText(
                    "Game over. Rating: " + game.getRating()
                            + " (" + game.countPegs()
                            + " peg(s) left)"
            );

        } else {

            statusLabel.setText(
                    "Move completed. Pegs remaining: "
                            + game.countPegs()
            );
        }
    }

    // Remove the currently selected peg coordinates.
    private void clearSelection() {
        selectedRow = -1;
        selectedCol = -1;
    }

    // Main method: launch the Swing application.
    public static void main(String[] args) {
        SwingUtilities.invokeLater(
                () -> new SolitaireGUI().setVisible(true)
        );
    }
}
