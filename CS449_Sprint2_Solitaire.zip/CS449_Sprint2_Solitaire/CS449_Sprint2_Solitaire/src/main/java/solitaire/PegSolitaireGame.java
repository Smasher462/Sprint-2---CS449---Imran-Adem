package solitaire;

/**
 * Contains all Peg Solitaire game rules and board state.
 */
public class PegSolitaireGame {

    /** Possible states for one location in the square backing grid. */
    public enum CellState {
        INVALID, // Location is outside the selected board shape.
        EMPTY,   // Valid board location with no peg.
        PEG      // Valid board location containing a peg.
    }

    private int size;
    private BoardType boardType;
    private CellState[][] board;

    /** Creates a new game using the requested size and board type. */
    public PegSolitaireGame(int size, BoardType boardType) {
        startNewGame(size, boardType);
    }

    /**
     * Starts a fresh game using the chosen settings.
     * Every playable location starts with a peg except the center hole.
     */
    public final void startNewGame(int size, BoardType boardType) {
        validateSize(size);
        if (boardType == null) {
            throw new IllegalArgumentException("Board type cannot be null.");
        }

        this.size = size;
        this.boardType = boardType;
        this.board = new CellState[size][size];
        initializeBoard();
    }

    /** Initializes the selected board shape and leaves the center empty. */
    private void initializeBoard() {
        int center = size / 2;

        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if (isPlayablePosition(row, col)) {
                    board[row][col] = CellState.PEG;
                } else {
                    board[row][col] = CellState.INVALID;
                }
            }
        }

        board[center][center] = CellState.EMPTY;
    }

    /**
     * Returns whether a grid location belongs to the selected board shape.
     */
    private boolean isPlayablePosition(int row, int col) {
        int center = size / 2;

        return switch (boardType) {
            case ENGLISH -> {
                // For size 7 this creates the familiar 33-hole cross board.
                int arm = Math.max(1, size / 3);
                int bandStart = arm;
                int bandEnd = size - arm - 1;
                boolean inCenterRows = row >= bandStart && row <= bandEnd;
                boolean inCenterColumns = col >= bandStart && col <= bandEnd;
                yield inCenterRows || inCenterColumns;
            }
            case DIAMOND ->
                    Math.abs(row - center) + Math.abs(col - center) <= center;
            case HEXAGON -> {
                // Axial-coordinate style hexagon represented in a square array.
                int q = col - center;
                int r = row - center;
                yield Math.max(Math.max(Math.abs(q), Math.abs(r)), Math.abs(q + r)) <= center;
            }
        };
    }

    /**
     * Checks whether a requested move follows the project rules.
     * A peg may jump exactly two cells orthogonally or diagonally over a peg
     * and must land in an empty playable location.
     */
    public boolean isValidMove(int fromRow, int fromCol, int toRow, int toCol) {
        if (!isInBounds(fromRow, fromCol) || !isInBounds(toRow, toCol)) {
            return false;
        }
        if (board[fromRow][fromCol] != CellState.PEG || board[toRow][toCol] != CellState.EMPTY) {
            return false;
        }

        int rowDifference = toRow - fromRow;
        int colDifference = toCol - fromCol;

        boolean orthogonalJump =
                (Math.abs(rowDifference) == 2 && colDifference == 0)
                        || (rowDifference == 0 && Math.abs(colDifference) == 2);
        boolean diagonalJump =
                Math.abs(rowDifference) == 2 && Math.abs(colDifference) == 2;

        if (!orthogonalJump && !diagonalJump) {
            return false;
        }

        int jumpedRow = (fromRow + toRow) / 2;
        int jumpedCol = (fromCol + toCol) / 2;
        return board[jumpedRow][jumpedCol] == CellState.PEG;
    }

    /**
     * Performs a move if it is valid.
     *
     * @return true when the move was completed; false when it was rejected.
     */
    public boolean makeMove(int fromRow, int fromCol, int toRow, int toCol) {
        if (!isValidMove(fromRow, fromCol, toRow, toCol)) {
            return false;
        }

        int jumpedRow = (fromRow + toRow) / 2;
        int jumpedCol = (fromCol + toCol) / 2;

        board[fromRow][fromCol] = CellState.EMPTY;
        board[jumpedRow][jumpedCol] = CellState.EMPTY;
        board[toRow][toCol] = CellState.PEG;
        return true;
    }

    /** Returns true if at least one legal move remains on the board. */
    public boolean hasValidMoves() {
        int[] offsets = {-2, 0, 2};

        for (int row = 0; row < size; row++) {
            for (int col = 0; col < size; col++) {
                if (board[row][col] != CellState.PEG) {
                    continue;
                }

                for (int rowOffset : offsets) {
                    for (int colOffset : offsets) {
                        if (rowOffset == 0 && colOffset == 0) {
                            continue;
                        }
                        // Do not allow a one-axis zero mixed with anything except a two-cell jump.
                        if (Math.abs(rowOffset) != 2 && rowOffset != 0) {
                            continue;
                        }
                        if (Math.abs(colOffset) != 2 && colOffset != 0) {
                            continue;
                        }

                        int targetRow = row + rowOffset;
                        int targetCol = col + colOffset;
                        if (isValidMove(row, col, targetRow, targetCol)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /** A manual game ends with one peg left or when no valid moves remain. */
    public boolean isGameOver() {
        return countPegs() == 1 || !hasValidMoves();
    }

    /** Counts the pegs currently remaining on the board. */
    public int countPegs() {
        int count = 0;
        for (CellState[] row : board) {
            for (CellState cell : row) {
                if (cell == CellState.PEG) {
                    count++;
                }
            }
        }
        return count;
    }

    /** Returns the rating specified by the project once a game has ended. */
    public String getRating() {
        if (!isGameOver()) {
            return "Game in progress";
        }
        return ratingForPegCount(countPegs());
    }

    /** Converts a final peg count to the rating stated in the project overview. */
    public static String ratingForPegCount(int pegCount) {
        if (pegCount <= 0) {
            throw new IllegalArgumentException("Peg count must be at least 1.");
        }
        if (pegCount == 1) {
            return "Outstanding";
        }
        if (pegCount == 2) {
            return "Very Good";
        }
        if (pegCount == 3) {
            return "Good";
        }
        return "Average";
    }

    /** Returns the state of one location so the GUI can draw the board. */
    public CellState getCell(int row, int col) {
        if (!isInBounds(row, col)) {
            throw new IndexOutOfBoundsException("Cell is outside the board.");
        }
        return board[row][col];
    }

    public int getSize() {
        return size;
    }

    public BoardType getBoardType() {
        return boardType;
    }

    private boolean isInBounds(int row, int col) {
        return row >= 0 && row < size && col >= 0 && col < size;
    }

    /**
     * Support manageable odd board sizes from 5 through 15.
     */
    private void validateSize(int size) {
        if (size < 5 || size > 15 || size % 2 == 0) {
            throw new IllegalArgumentException("Board size must be an odd number from 5 through 15.");
        }
    }
}
