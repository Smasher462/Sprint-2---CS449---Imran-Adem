package solitaire;

/**
 * The board layouts available in Sprint 2.
 */
public enum BoardType {
    ENGLISH,
    HEXAGON,
    DIAMOND
}
